## Create `.icns` and `.ico` files
  - Go to: http://iconverticons.com/online/ to convert .svg to `.icns` and `.ico` files
  - For `.icns` select `icns file` (not `finder ready`).